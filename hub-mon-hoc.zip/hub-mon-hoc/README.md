# Hub môn học

Trang tĩnh gom các trang tự học theo môn. Mỗi môn là một file HTML trong `mon/`.

## Deploy lên GitHub Pages
1. Tạo repo mới trên GitHub (public), ví dụ `hub-mon-hoc`.
2. Trong thư mục này chạy:
```
git init
git add .
git commit -m "Hub môn học"
git branch -M main
git remote add origin https://github.com/<ten-ban>/hub-mon-hoc.git
git push -u origin main
```
3. Repo → Settings → Pages → Source: Deploy from a branch → `main` / `(root)` → Save.
4. Sau 1–2 phút trang chạy tại `https://<ten-ban>.github.io/hub-mon-hoc/`.

## Thêm môn vào repo
1. Bỏ file HTML vào `mon/` (tên không dấu, ví dụ `vat-ly-1.html`).
2. Thêm một mục vào khối `<script type="application/json" id="seed">` trong `index.html`, trường `src` là `mon/vat-ly-1.html`.
3. `git add . && git commit -m "Them mon" && git push`.

## Cập nhật nội dung một môn
Ghi đè file trong `mon/`, rồi `git commit` và `git push`.

Lưu ý: môn thêm hoặc sửa bằng giao diện hub chỉ nằm trong trình duyệt đang dùng (nút Sao lưu để xuất ra file). Muốn đưa lên web thì làm theo các bước trên.
